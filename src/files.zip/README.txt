WELCOME TO DESERT WARS!

This is an endless scroller game in which the goal is to survive as long as
you possibly can against the barrage of enemy space crafts that fly in towards
you. Move your space ship around the screen with the intuitively programmed arrow 
keys, but watch out for the enemies! Colliding with any of the ordinary enemies
lowers your life by 1 until it reaches 0 - in which case it's game over.

To make things a little easier, you're provided with 3 initial lives. You're also
given 20 missiles, which can be fired with the SPACE bar to destroy enemies you 
think you can't avoid in time. 

After intervals in the game, the enemies may morph into AI-powered bosses which
are significantly harder to avoid. Be careful you don't use up all your ammo 
because you'll probably need at least 3 missiles to kill them. Once you do kill a
boss however, your lives and weapons are replenished.

Cool features:
- Automatic storage and updating of high scores done using File I/O
- Intelligent Bosses that have two modes of attacking the player.
- Konami cheat code (make sure you punch it in correctly) to get 100 missiles!
- Super sweet acceleration themed background animation that changes dynamically 
